// ==========================================
// AI Vision Pro - JavaScript
// ==========================================

// Hugging Face API Configuration
// Get free API key from: https://huggingface.co/settings/tokens
const API_KEY = 'hf_WyMMnTrMcDJaQKUKsAZyVYJwcDAcGaKMCJhf_WyMMnTrMcDJaQKUKsAZyVYJwcDAcGaKMCJ'; // <-- Apna API key yahan daalein
const API_URL = 'https://api-inference.huggingface.co/models/google/vit-base-patch16-224';

// Elements
const uploadArea = document.getElementById('uploadArea');
const imageInput = document.getElementById('imageInput');
const browseBtn = document.getElementById('browseBtn');
const previewSection = document.getElementById('previewSection');
const previewImage = document.getElementById('previewImage');
const removeBtn = document.getElementById('removeBtn');
const analyzeBtn = document.getElementById('analyzeBtn');
const loadingSection = document.getElementById('loadingSection');
const resultsSection = document.getElementById('resultsSection');
const resultImage = document.getElementById('resultImage');
const resultsList = document.getElementById('resultsList');
const newBtn = document.getElementById('newBtn');
const errorSection = document.getElementById('errorSection');
const errorMessage = document.getElementById('errorMessage');
const retryBtn = document.getElementById('retryBtn');

let selectedFile = null;
let imageBase64 = null;

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    setupEventListeners();
});

function setupEventListeners() {
    // Browse button
    browseBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        imageInput.click();
    });

    // Upload area click
    uploadArea.addEventListener('click', () => {
        imageInput.click();
    });

    // Drag and drop
    uploadArea.addEventListener('dragover', (e) => {
        e.preventDefault();
        uploadArea.classList.add('dragover');
    });

    uploadArea.addEventListener('dragleave', () => {
        uploadArea.classList.remove('dragover');
    });

    uploadArea.addEventListener('drop', (e) => {
        e.preventDefault();
        uploadArea.classList.remove('dragover');
        if (e.dataTransfer.files.length > 0) {
            handleFile(e.dataTransfer.files[0]);
        }
    });

    // File input
    imageInput.addEventListener('change', (e) => {
        if (e.target.files.length > 0) {
            handleFile(e.target.files[0]);
        }
    });

    // Remove button
    removeBtn.addEventListener('click', resetToUpload);

    // Analyze button
    analyzeBtn.addEventListener('click', analyzeImage);

    // New analysis button
    newBtn.addEventListener('click', resetToUpload);

    // Retry button
    retryBtn.addEventListener('click', resetToUpload);
}

function handleFile(file) {
    // Validate file type
    const validTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    if (!validTypes.includes(file.type)) {
        showError('Please select a valid image (JPG, PNG, GIF, WEBP)');
        return;
    }

    // Validate file size (5MB max)
    if (file.size > 5 * 1024 * 1024) {
        showError('Image size must be less than 5MB');
        return;
    }

    selectedFile = file;

    // Read file
    const reader = new FileReader();
    reader.onload = (e) => {
        imageBase64 = e.target.result;
        previewImage.src = imageBase64;
        showSection('preview');
    };
    reader.readAsDataURL(file);
}

async function analyzeImage() {
    if (!selectedFile) return;

    showSection('loading');

    try {
        // Convert to blob
        const response = await fetch(imageBase64);
        const blob = await response.blob();

        // Call Hugging Face API
        const result = await fetch(API_URL, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${API_KEY}`,
                'Content-Type': 'application/octet-stream'
            },
            body: blob
        });

        if (!result.ok) {
            throw new Error('API request failed');
        }

        const data = await result.json();

        if (data.error) {
            throw new Error(data.error);
        }

        displayResults(data);

    } catch (error) {
        console.error('Error:', error);
        showError(error.message || 'Failed to analyze image. Please try again.');
    }
}

function displayResults(results) {
    resultImage.src = imageBase64;
    resultsList.innerHTML = '';

    // Take top 5 results
    const topResults = results.slice(0, 5);

    topResults.forEach((item, index) => {
        const score = (item.score * 100).toFixed(1);
        const label = formatLabel(item.label);

        const resultItem = document.createElement('div');
        resultItem.className = 'result-item';
        resultItem.style.animationDelay = `${index * 0.1}s`;

        resultItem.innerHTML = `
            <div class="result-info">
                <div class="result-icon">
                    <i class="fas fa-tag"></i>
                </div>
                <span class="result-name">${label}</span>
            </div>
            <div class="result-score">
                <div class="score-bar">
                    <div class="score-fill" style="width: ${score}%"></div>
                </div>
                <span class="score-value">${score}%</span>
            </div>
        `;

        resultsList.appendChild(resultItem);
    });

    showSection('results');
}

function formatLabel(label) {
    return label
        .replace(/_/g, ' ')
        .split(' ')
        .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
        .join(' ');
}

function showSection(section) {
    // Hide all sections
    uploadArea.style.display = 'none';
    previewSection.style.display = 'none';
    loadingSection.style.display = 'none';
    resultsSection.style.display = 'none';
    errorSection.style.display = 'none';

    // Show selected section
    switch (section) {
        case 'upload':
            uploadArea.style.display = 'block';
            break;
        case 'preview':
            previewSection.style.display = 'block';
            break;
        case 'loading':
            loadingSection.style.display = 'block';
            break;
        case 'results':
            resultsSection.style.display = 'block';
            break;
        case 'error':
            errorSection.style.display = 'block';
            break;
    }
}

function showError(message) {
    errorMessage.textContent = message;
    showSection('error');
}

function resetToUpload() {
    selectedFile = null;
    imageBase64 = null;
    imageInput.value = '';
    previewImage.src = '';
    resultImage.src = '';
    resultsList.innerHTML = '';
    showSection('upload');
}